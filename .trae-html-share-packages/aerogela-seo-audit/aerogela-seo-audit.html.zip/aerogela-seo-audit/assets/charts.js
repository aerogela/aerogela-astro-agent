(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  var baseText = { color: ink, fontFamily: 'Instrument Sans, Noto Sans CJK SC, sans-serif' };

  // ---------- 图 1: Sitemap URL 分布 ----------
  var smEl = document.getElementById('chart-sitemap');
  if (smEl) {
    var sm = echarts.init(smEl, null, { renderer: 'svg' });
    sm.setOption({
      animation: false,
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, appendToBody: true,
        valueFormatter: function(v) { return v + ' 个 URL'; } },
      grid: { left: 150, right: 60, top: 20, bottom: 30 },
      xAxis: { type: 'value', axisLabel: { color: muted }, splitLine: { lineStyle: { color: rule } } },
      yAxis: {
        type: 'category',
        inverse: true,
        data: ['企业列表 hp_listing', '静态页面 page', '博客文章 post', '标签 post_tag', '地域 location', '主营产品 main_products', '应用领域 application_fields', '博客分类 category', '供应商 vendor', '列表主分类 listing_category'],
        axisLabel: { color: ink, fontSize: 12 },
        axisLine: { lineStyle: { color: rule } }
      },
      series: [{
        type: 'bar',
        data: [134, 47, 36, 34, 21, 15, 13, 2, 2, 4],
        barWidth: '62%',
        itemStyle: { color: accent, borderRadius: [0, 3, 3, 0] },
        label: { show: true, position: 'right', color: ink, fontFamily: 'JetBrains Mono, monospace', fontSize: 11 }
      }]
    });
    window.addEventListener('resize', function() { sm.resize(); });
  }

  // ---------- 图 3: TTFB / 总耗时 ----------
  var tEl = document.getElementById('chart-timing');
  if (tEl) {
    var tc = echarts.init(tEl, null, { renderer: 'svg' });
    tc.setOption({
      animation: false,
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, appendToBody: true,
        valueFormatter: function(v) { return v + ' s'; } },
      legend: { top: 0, textStyle: baseText },
      grid: { left: 50, right: 30, top: 40, bottom: 30 },
      xAxis: { type: 'category', data: ['第 1 次', '第 2 次', '第 3 次'], axisLabel: { color: ink }, axisLine: { lineStyle: { color: rule } } },
      yAxis: { type: 'value', name: '秒', nameTextStyle: { color: muted }, axisLabel: { color: muted, formatter: '{value}s' }, splitLine: { lineStyle: { color: rule } } },
      series: [
        { name: 'TTFB（首字节）', type: 'bar', data: [1.50, 2.76, 1.97], barWidth: '28%', itemStyle: { color: accent, borderRadius: [3, 3, 0, 0] }, label: { show: true, position: 'top', color: ink, fontFamily: 'JetBrains Mono, monospace', fontSize: 11, formatter: '{c}s' } },
        { name: '全页下载完成', type: 'bar', data: [2.01, 5.71, 3.74], barWidth: '28%', itemStyle: { color: accent2, borderRadius: [3, 3, 0, 0] }, label: { show: true, position: 'top', color: ink, fontFamily: 'JetBrains Mono, monospace', fontSize: 11, formatter: '{c}s' } },
        { name: 'TTFB 良好阈值 0.8s', type: 'line', markLine: { silent: true, symbol: 'none', lineStyle: { color: '#d64541', type: 'dashed' }, data: [{ yAxis: 0.8 }], label: { color: '#d64541', formatter: '0.8s 良好阈值', position: 'insideEndTop' } }, data: [] }
      ]
    });
    window.addEventListener('resize', function() { tc.resize(); });
  }

  // ---------- 图 4: 页面载荷构成 ----------
  var wEl = document.getElementById('chart-weight');
  if (wEl) {
    var wc = echarts.init(wEl, null, { renderer: 'svg' });
    wc.setOption({
      animation: false,
      tooltip: { trigger: 'item', appendToBody: true,
        formatter: function(p) { return p.name + '<br/>' + p.value + ' KB（' + p.percent + '%）'; } },
      legend: { orient: 'vertical', right: 10, top: 'center', textStyle: baseText, itemGap: 14 },
      series: [{
        type: 'pie',
        radius: ['42%', '68%'],
        center: ['36%', '50%'],
        data: [
          { name: '单张未压缩原图（JPEG）', value: 4380, itemStyle: { color: '#d64541' } },
          { name: '其他 JPEG 图片（8 张）', value: 330, itemStyle: { color: accent2 } },
          { name: 'JavaScript（28 个文件）', value: 265, itemStyle: { color: accent } },
          { name: 'HTML 文档', value: 150, itemStyle: { color: muted } },
          { name: 'PNG / WebP / CSS', value: 24, itemStyle: { color: rule } }
        ],
        label: { color: ink, fontFamily: 'JetBrains Mono, monospace', fontSize: 11, formatter: '{b}\n{c}KB · {d}%' },
        emphasis: { itemStyle: { shadowBlur: 8, shadowColor: 'rgba(0,0,0,0.12)' } }
      }]
    });
    window.addEventListener('resize', function() { wc.resize(); });
  }
})();
